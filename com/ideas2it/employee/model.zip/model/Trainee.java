package com.ideas2it.employee.model;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import com.ideas2it.employee.common.Gender;
import java.util.List;
import java.util.ArrayList;
import com.ideas2it.employee.model.Employee;

/**
 * <h2>Trainee</h2>
 * <p>
 * It is a model class for trainee conatins details of trainee
 * and contains getter to access the variables and setter to set the values in the variable.
 * </p>
 *
 * @author Akash Siva
 * @version 1.0
 * @since 12-08-2022
 **/
public class Trainee extends Employee {
    private int trainingPeriod;
    private int traineeId;
    private Employee employee;

    /**
     * <p>
     * It is a constructer for Trainee class that extends Employee.
     * </p>
     *
     * @param {@link int} id - id of the trainee
     * @param {@link String} name - name of the trainee
     * @param {@link String} dateOfBirth - date of Birth of trainee
     * @param {@link int} age - age of trainee
     * @param {@link String} gender - Gender of trainee
     * @param {@link String} qualification - Qualifiacation of trainee
     * @param {@link String} address - address of trainee
     * @param {@link Long} mobileNumber - mobile number of trainee
     * @param {@link String} emailId - mail id of trainee
     * @param {@link LocalDate} dateOfJoining - date of joining of trainee
     * @param {@link List<String>} trainersId - trainer Id who is incharge for the trainee
     * @param {@link int} trainingPeriod - training period of the trainee
     *
     * @return {@link void} return nothing.
     **/
    public Trainee (int id, String name, LocalDate dateOfBirth, int age, 
                    String gender, String qualification, String address, 
                    long mobileNumber, String emailId, LocalDate dateOfJoining, int trainingPeriod) {
	super(id, name, dateOfBirth, age, gender, qualification, address, mobileNumber, emailId, dateOfJoining);	
        this.trainingPeriod = trainingPeriod;
    }

    /**
     * <p>
     * It is a copy constructer for Trainee class that create a copy of the object.
     * </p>
     *
     * @param {@link Trainee} trainee - object of the trainee.
     *   
     * @return {@link void} return nothing.
     **/  
    public Trainee(Trainee trainee) {
        super(trainee);
        this.trainingPeriod = trainee.trainingPeriod;
        this.traineeId = trainee.traineeId;
    }

    public void setTraineeId(int traineeId) {
        this.traineeId = traineeId;
    }

    public int getTraineeId() {
	return traineeId;
    }

    public void setTrainingPeriod(int trainingPeriod) {
        this.trainingPeriod = trainingPeriod;
    }

    public int getTrainingPeriod() {
	return trainingPeriod;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    public Employee getEmployee() {
	return employee;
    }
    /**
     * <p>
     * overrided toString method
     * </p>
     *
     * @return {@link String} return formated string.
     **/
    @Override
    public String toString() {
	return  "\n" + "ID of Employee : " + getId() +"\n"+ "Name of the Trainee : " + getName() +"\n"+
            "Age : " + getAge() +"\n"+ "Gender : " + getGender() + "\n" +
            "Qualifications : " + getQualification() +"\n"+ "Address : " + getAddress() +
            "\n" + "Mobile Number : " + getMobileNumber() + "\nEmail Id : " + getEmailId() + "\n" +
            "Date Of Joining : " + getDateOfJoining().format(DateTimeFormatter.ofPattern("d/MM/yyyy")) +
             "\nTraining Period : " + getTrainingPeriod() + "\n";
    }

    /**
     * <p>
     * overrided the equals method. To check the required field.
     * </p>
     *
     * @param {@link Object) o.
     *
     * @return {@link boolean} return true if all the condition satisfied else false.
     **/
    @Override
    public boolean equals(Object o) {
        Trainee trainee = (Trainee)o;
        if (!(this.getId() == trainee.getId()) &&
            !(this.getName().equals(trainee.getName())) &&
            !(this.getGender().equals(trainee.getGender()))) {
            return false;
        }
        return true;
    }

    /**
     * <p>
     * overrided the hashCode method. to generate the hashcode for the trainee object as 0.
     * </p>
     *
     * @return {@link int} return hashcode of all object as 0;
     **/    
    @Override
    public int hashCode() {
        return 0;
    }  
}