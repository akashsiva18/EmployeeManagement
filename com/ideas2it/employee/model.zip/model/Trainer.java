package com.ideas2it.employee.model;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.ArrayList;
import com.ideas2it.employee.model.Employee;

/**
 * <h2>Trainer</h2>
 * <p>
 * It is a model class for trainer conatins details of trainer
 * and contains getter to access the variables and setter to set the values in the variable.
 * </p>
 *
 * @author Akash Siva
 * @version 1.0
 * @since 12-08-2022
 **/
public class Trainer extends Employee {		

    private int experience;
    private int noOfTrainees;
    private int trainerId;
    private Employee employee;
    /**
     * <p>
     * It is a constructer for Trainer class that extends Employee.
     * </p>
     *
     * @param {@link int} id - id of the trainer
     * @param {@link String} dateOfBirth - date of Birth of trainer
     * @param {@link int} age - age of trainer
     * @param {@link String} gender - Gender of trainer
     * @param {@link String} qualification - Qualifiacation of trainer
     * @param {@link String} address - address of trainer
     * @param {@link Long} mobileNumber - mobile number of trainer
     * @param {@link String} emailId - mail id of trainer
     * @param {@link LocalDate} dateOfJoining - date of joining of trainer
     * @param {@link int} experiance - experiance of trainer
     *
     * @return {@link void} return nothing.
     **/
    public Trainer(int id, String name, LocalDate dateOfBirth, int age, String gender, String qualification,
	           String address, long mobileNumber, String emailId, LocalDate dateOfJoining,
 	           int experience) {
        super(id, name, dateOfBirth, age, gender, qualification, address, mobileNumber, emailId, dateOfJoining);
	this.experience = experience;
    }

    /**
     * <p>
     * It is a copy constructer for Trainee class that create a copy of the object.
     * </p>
     *
     * @param {@link Trainer} trainer - object of the Trainer.
     *   
     * @return {@link void} return nothing.
     **/  
    public Trainer(Trainer trainer) {
        super(trainer);        
        this.experience = trainer.experience;
        this.trainerId = trainer.trainerId;
    }

    public void setExperience(int experience) {
	this.experience = experience;
    }

    public int getExperience() {
	return experience;
    }

    public int getNoOfTrainees() {
        return noOfTrainees;
    }

    public void setNoOfTrainees(int noOfTrainees) {
        this.noOfTrainees = noOfTrainees;
    }

    public void setTrainerId(int trainerId) {
        this.trainerId = trainerId;
    }

    public int getTrainerId() {
	return trainerId;
    }
    
    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    public Employee getEmployee() {
	return employee;
    }

    /**
     * <p>
     * overrided toString method
     * </p>
     *
     * @return {@link String} return formated string.
     **/
    @Override
    public String toString() {
	return "\n" + "ID of Employee : " + getId() +
	    "\n"+ "Name of the Trainer : " + getName() +
            "\n"+ "Age : " + getAge() + "\n" + "Gender : " + getGender() + 
            "\n" + "Qualifications : " + getQualification() +"\n" + "Address : " +
            getAddress() + "\n" + "Mobile Number : " + getMobileNumber() +
            "\n" + "Email Id : " + getEmailId() + "\n" + "Date Of Joining : " + 
            getDateOfJoining().format(DateTimeFormatter.ofPattern("d/MM/yyyy")) +
            "\n" + "Training Experience : " + getExperience() + "\nNo Of Trainees : " +
            getNoOfTrainees() + "\n";
    }


    /**
     * <p>
     * overrided the equals method. To check the required field.
     * </p>
     *
     * @param {@link Object) o.
     *
     * @return {@link boolean} return true if all the condition satisfied else false.
     **/
    @Override
    public boolean equals(Object o) {
        Trainer trainer = (Trainer)o;
        if (!(this.getId() == trainer.getId()) &&
            !(this.getName().equals(trainer.getName())) &&
            !(this.getGender().equals(trainer.getGender()))) {
            return false;
        }
        return true;
    }

    /**
     * <p>
     * overrided the hashCode method. to generate the hashcode for the trainee object as 0.
     * </p>
     *
     * @return {@link int} return hashcode of all object as 0;
     **/    
    @Override
    public int hashCode() {
        return 1;
    }

}

    
