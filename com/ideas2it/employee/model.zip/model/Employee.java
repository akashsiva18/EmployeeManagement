package com.ideas2it.employee.model;

import java.time.LocalDate;
import com.ideas2it.employee.common.Gender;
import com.ideas2it.employee.model.Trainee;
import com.ideas2it.employee.model.Trainer;

/**
 * <h2>Employee</h2>
 * <p>
 * It is a model class for employee conatins common details of employees
 * and contains getter to access the variables and setter to set the values in the variable.
 * </p>
 *
 * @author Akash Siva
 * @version 1.0
 * @since 12-08-2022
 **/
public class Employee {
    private int id;
    private String name;
    private LocalDate dateOfBirth;
    private int age;
    private String gender;
    private String qualification;
    private String address;
    private long mobileNumber;
    private String emailId;
    private LocalDate dateOfJoining;
    private Trainer trainer;
    private Trainee trainee;


    /**
     * <p>
     * It is a constructer for employee class.
     * </p>
     *
     * @param {@link int} id
     * @param {@link String} dateOfBirth
     * @param {@link int} age
     * @param {@link String} gender
     * @param {@link String} qualification
     * @param {@link String} address
     * @param {@link Long} mobileNumber
     * @param {@link String} emailId
     * @param {@link LocalDate} dateOfJoining
     *   
     * @return {@link void} return nothing.
     **/    
    public Employee(int id, String name, LocalDate dateOfBirth, int age, String gender, String qualification,
	    String address, Long mobileNumber, String emailId, LocalDate dateOfJoining) {
	this.id = id;
	this.name = name;
	this.dateOfBirth = dateOfBirth;
        this.age = age;
        this.gender = gender;
	this.qualification = qualification;
	this.address = address;
	this.mobileNumber = mobileNumber;
        this.emailId = emailId;
	this.dateOfJoining = dateOfJoining;
    }

    /**
     * <p>
     * It is a copy constructer for employee class that create a copy of the object.
     * </p>
     *
     * @param {@link Employee} employee
     *   
     * @return {@link void} return nothing.
     **/  
    public Employee(Employee employee) {
        this.id = employee.id;
	this.name = employee.name;
	this.dateOfBirth = employee.dateOfBirth;
        this.age = employee.age;
        this.gender = employee.gender;
	this.qualification = employee.qualification;
	this.address = employee.address;
	this.mobileNumber = employee.mobileNumber;
        this.emailId = employee.emailId;
	this.dateOfJoining = employee.dateOfJoining;
    }
 
    public Employee(){}


    public void setId(int id) {
	this.id = id;
    }
 
    public int getId() {
	return id;
    }

    public void setName(String name) {
	this.name = name;
    }

    public String getName() {
	return name;
    }

    public void setDateOfBirth(LocalDate dateOfBirth) {
	this.dateOfBirth = dateOfBirth;
    }

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getAge() {
        return age;
    }

    public void setGender(String gender) {
	this.gender = gender;
    }

    public String getGender() {
	return gender;
    }

    public void setQualification(String qualification) {
	this.qualification = qualification;
    }

    public String getQualification() {
	return qualification;
    }

    public void setAddress(String address) {
	this.address = address;
    }

    public String getAddress() {
	return address;
    }

    public void setMobileNumber(Long mobileNumber) {
	this.mobileNumber = mobileNumber;
    }

    public long getMobileNumber() {
	return mobileNumber;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public String getEmailId() {
        return emailId;
    }
    
    public void setDateOfJoining(LocalDate dateOfJoining) {
	this.dateOfJoining = dateOfJoining;
    }

    public LocalDate getDateOfJoining() {
	return dateOfJoining;
    }

    public void setTrainer(Trainer trainer) {
	this.trainer = trainer;
    }

    public Trainer getTrainer() {
	return trainer;
    }

    public void setTrainee(Trainee trainee) {
	this.trainee = trainee;
    }

    public Trainee getTrainee() {
	return trainee;
    }
}
    